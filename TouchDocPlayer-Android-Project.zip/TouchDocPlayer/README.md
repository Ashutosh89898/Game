# TouchDoc Player — Android Studio project

A touch-first Android document player prototype inspired by the clean, familiar interaction model of Google Drive's document viewer.

## Included
- Native Android shell with a WebView-based touch UI.
- Android document picker (Storage Access Framework); no broad storage permission required.
- PDF page rendering using PDF.js, with page controls, vertical scrolling, swipe navigation and pinch zoom.
- PPTX preview using `@js-preview/pptx` loaded from esm.sh.
- Extracts media stored in a PPTX package (`ppt/media/`) and displays GIFs (animated by the browser) and supported videos with playback controls. Videos are muted and autoplay is attempted to comply with mobile autoplay policies.
- Standalone GIF and video playback.
- Dark, responsive interface.

## Build an APK
1. Install **Android Studio** (current stable) and its Android SDK Platform 35 / Build Tools.
2. Extract this ZIP.
3. In Android Studio choose **Open**, then select the `TouchDocPlayer` folder (the folder containing `settings.gradle`).
4. Allow Gradle sync and install any SDK components Android Studio requests.
5. Connect your Android phone with USB debugging enabled, or create an emulator.
6. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. Android Studio will show the APK location. Usually: `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
- The first launch / first use of PDF and PPTX preview requires internet access because PDF.js, JSZip and the PPTX preview module are loaded from public CDNs. For an offline production release, vendor these libraries into `app/src/main/assets` and update the script imports.
- PPTX slide fidelity varies. Some advanced PowerPoint effects, transitions, fonts, audio/video timing, and embedded OLE objects may not render exactly like Microsoft PowerPoint.
- Media embedded in PPTX is surfaced in a separate **Media in this presentation** section; the prototype does not guarantee exact in-slide media placement or PowerPoint trigger/timing behavior.
- PDF.js does not provide universal playback for every kind of embedded PDF RichMedia annotation. Ordinary video files and PPTX media assets are supported as described above.
- Legacy `.ppt` files are accepted by the picker but are not reliably rendered; convert them to `.pptx` or PDF first.
- Autoplay may be blocked by Android/WebView policies or device power settings. Videos are muted by default; tap the controls to enable sound.

## Project structure
```
TouchDocPlayer/
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/ashu/touchdoc/MainActivity.java
  app/src/main/assets/index.html
  app/build.gradle
  build.gradle
  settings.gradle
```
