# Bird Shooter — offline Android game

A simple, native Android 2D arcade game written in Kotlin. It uses Android Canvas, so the gameplay and graphics are bundled in the APK and work offline. No account, network permission, ads, or server is required.

## Gameplay
- Landscape full-screen play
- Tap flying cartoon birds to score 10 points
- 60-second round, 3 lives
- Replay after game over
- No internet connection required

## Build an APK from your phone (cloud build)
This project includes `.github/workflows/build-apk.yml` for GitHub Actions.

1. Extract this ZIP on your phone.
2. In GitHub, create a repository and upload the **contents** of this folder (including hidden `.github` folder). Do not upload the ZIP as a single file.
3. Commit the files to `main`.
4. Open the repository's **Actions** tab and select **Build Bird Shooter APK**. If needed, tap **Run workflow**.
5. When the run completes successfully, open it and download the `BirdShooter-APK` artifact.
6. Extract the artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from your browser or file manager.

The build is performed on GitHub's cloud runners, not on your phone. The installed game itself runs offline.

## Build locally
Open this project in Android Studio and run the `assembleDebug` Gradle task.
