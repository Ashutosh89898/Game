package com.ashu.birdshooter

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.hypot
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        setContentView(GameView(this))
    }
}

private data class Bird(var x: Float, var y: Float, var speed: Float, var size: Float, var dir: Float, var color: Int)

private class GameView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val birds = mutableListOf<Bird>()
    private var score = 0
    private var lives = 3
    private var timeLeft = 60f
    private var lastTime = System.nanoTime()
    private var started = false
    private var gameOver = false
    private var shotX = -100f
    private var shotY = -100f
    private var shotFlash = 0f
    private var spawnTimer = 0f
    private val colors = intArrayOf(Color.rgb(35, 155, 86), Color.rgb(177, 95, 45), Color.rgb(70, 115, 200), Color.rgb(220, 145, 30))

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val dt = ((System.nanoTime() - lastTime) / 1_000_000_000f).coerceAtMost(0.05f)
        lastTime = System.nanoTime()
        drawBackground(canvas)
        if (!started) { drawMenu(canvas); postInvalidateOnAnimation(); return }
        if (!gameOver) update(dt)
        birds.forEach { drawBird(canvas, it) }
        drawHud(canvas)
        if (shotFlash > 0f) {
            p.color = Color.WHITE; p.style = Paint.Style.STROKE; p.strokeWidth = 4f
            canvas.drawCircle(shotX, shotY, 22f * (1.15f - shotFlash), p)
            canvas.drawLine(shotX - 12, shotY, shotX + 12, shotY, p)
            canvas.drawLine(shotX, shotY - 12, shotX, shotY + 12, p)
            p.style = Paint.Style.FILL; shotFlash -= dt * 3f
        }
        if (gameOver) drawGameOver(canvas)
        postInvalidateOnAnimation()
    }

    private fun drawBackground(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(Color.rgb(48, 164, 239))
        p.color = Color.rgb(125, 210, 255)
        c.drawCircle(w * .12f, h * .30f, h * .13f, p); c.drawCircle(w * .18f, h * .27f, h * .17f, p); c.drawCircle(w * .24f, h * .31f, h * .12f, p)
        c.drawCircle(w * .77f, h * .22f, h * .11f, p); c.drawCircle(w * .83f, h * .19f, h * .15f, p); c.drawCircle(w * .89f, h * .23f, h * .10f, p)
        p.color = Color.rgb(80, 174, 104)
        val hill = android.graphics.Path().apply { moveTo(0f,h*.77f); cubicTo(w*.18f,h*.42f,w*.32f,h*.78f,w*.5f,h*.58f); cubicTo(w*.69f,h*.38f,w*.83f,h*.74f,w,h*.53f); lineTo(w,h); lineTo(0f,h); close() }
        c.drawPath(hill,p)
        p.color = Color.rgb(28, 117, 78)
        c.drawRect(0f,h*.83f,w,h,p)
        p.color = Color.rgb(32, 143, 207); c.drawRect(0f,h*.91f,w,h,p)
    }

    private fun drawMenu(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.color = Color.rgb(105, 57, 25); c.drawRoundRect(RectF(w*.25f,h*.16f,w*.75f,h*.34f),24f,24f,p)
        text(c, "BIRD SHOOTER", w*.5f, h*.275f, h*.085f, Color.rgb(255,196,61), true, Paint.Align.CENTER)
        p.color = Color.rgb(34, 171, 57); c.drawRoundRect(RectF(w*.38f,h*.52f,w*.62f,h*.67f),22f,22f,p)
        text(c, "TAP TO PLAY", w*.5f, h*.615f, h*.05f, Color.WHITE, true, Paint.Align.CENTER)
        text(c, "Tap flying birds to score points • 60 seconds • 3 misses allowed", w*.5f, h*.78f, h*.032f, Color.WHITE, false, Paint.Align.CENTER)
    }

    private fun update(dt: Float) {
        timeLeft -= dt
        if (timeLeft <= 0f || lives <= 0) { timeLeft = timeLeft.coerceAtLeast(0f); gameOver = true; return }
        spawnTimer -= dt
        if (spawnTimer <= 0f && birds.size < 7) {
            val size = height * Random.nextDouble(.035, .055).toFloat()
            val left = Random.nextBoolean()
            birds.add(Bird(if (left) -size else width + size, height * Random.nextDouble(.20, .72).toFloat(), height * Random.nextDouble(.25, .43).toFloat(), size, if (left) 1f else -1f, colors.random()))
            spawnTimer = Random.nextDouble(.65, 1.15).toFloat()
        }
        val iter = birds.iterator()
        while (iter.hasNext()) {
            val b = iter.next(); b.x += b.speed * b.dir * dt
            if (b.x < -b.size * 2 || b.x > width + b.size * 2) { iter.remove(); lives-- }
        }
    }

    private fun drawBird(c: Canvas, b: Bird) {
        c.save(); c.translate(b.x, b.y); if (b.dir < 0) c.scale(-1f,1f)
        p.color = b.color; c.drawOval(RectF(-b.size*.48f,-b.size*.18f,b.size*.38f,b.size*.22f),p)
        p.color = Color.rgb(245, 223, 176)
        val wing = android.graphics.Path().apply { moveTo(-b.size*.15f,0f); lineTo(-b.size*.18f,-b.size*.68f); lineTo(b.size*.35f,-b.size*.22f); close() }; c.drawPath(wing,p)
        p.color = b.color; c.drawCircle(b.size*.34f,-b.size*.12f,b.size*.22f,p)
        p.color = Color.rgb(255, 177, 38); val beak = android.graphics.Path().apply { moveTo(b.size*.48f,-b.size*.14f); lineTo(b.size*.77f,-b.size*.07f); lineTo(b.size*.48f,0f); close() }; c.drawPath(beak,p)
        p.color = Color.WHITE; c.drawCircle(b.size*.39f,-b.size*.18f,b.size*.055f,p); p.color = Color.BLACK; c.drawCircle(b.size*.405f,-b.size*.18f,b.size*.025f,p)
        c.restore()
    }

    private fun drawHud(c: Canvas) {
        p.color = 0xB9002038.toInt(); c.drawRoundRect(RectF(18f,18f,250f,112f),18f,18f,p)
        text(c,"SCORE  $score",34f,56f,30f,Color.WHITE,true,Paint.Align.LEFT)
        text(c,"TIME  ${timeLeft.toInt()}s",34f,94f,26f,Color.WHITE,true,Paint.Align.LEFT)
        text(c,"♥ ".repeat(lives.coerceAtLeast(0)),width-35f,55f,36f,Color.rgb(255,75,84),true,Paint.Align.RIGHT)
        text(c,"TAP A BIRD TO SHOOT",width*.5f,height-22f,22f,Color.WHITE,true,Paint.Align.CENTER)
    }

    private fun drawGameOver(c: Canvas) {
        p.color = 0xD9001526.toInt(); c.drawRect(0f,0f,width.toFloat(),height.toFloat(),p)
        p.color = Color.rgb(105,57,25); c.drawRoundRect(RectF(width*.30f,height*.23f,width*.70f,height*.76f),24f,24f,p)
        text(c,"GAME OVER",width*.5f,height*.37f,height*.075f,Color.rgb(255,196,61),true,Paint.Align.CENTER)
        text(c,"Final score: $score",width*.5f,height*.49f,height*.045f,Color.WHITE,true,Paint.Align.CENTER)
        p.color = Color.rgb(34,171,57); c.drawRoundRect(RectF(width*.39f,height*.57f,width*.61f,height*.69f),18f,18f,p)
        text(c,"PLAY AGAIN",width*.5f,height*.645f,height*.032f,Color.WHITE,true,Paint.Align.CENTER)
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean, align: Paint.Align) {
        p.color = color; p.textSize = size; p.typeface = if (bold) android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) else android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL); p.textAlign = align; p.style = Paint.Style.FILL; c.drawText(s,x,y,p)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_DOWN) return true
        val x = event.x; val y = event.y
        if (!started) { started = true; return true }
        if (gameOver) {
            if (y > height*.54f && y < height*.73f) { score=0; lives=3; timeLeft=60f; birds.clear(); gameOver=false; spawnTimer=0f }
            else { started=false; gameOver=false }
            return true
        }
        shotX=x; shotY=y; shotFlash=1f
        val hit = birds.minByOrNull { hypot((it.x-x).toDouble(),(it.y-y).toDouble()) }
        if (hit != null && hypot((hit.x-x).toDouble(),(hit.y-y).toDouble()) < hit.size*1.7) { birds.remove(hit); score += 10 }
        else { /* missed shots do not consume a life; birds that escape do */ }
        invalidate(); return true
    }
}
